abiepwae@yahoo.com

Hi, I decided to choose this font's license Free but commercial use requires donations. I never know how much my fonts help, that's why there's no specific price. I license them as it called donationware so people can just pay the amount I deserve. So far I don't plan to upload this font to marketplace or elsewhere rather than fontspace.
If you have any questions simply contact me.